function [ grad_J,Jw ] = gradJ_logistic( y,theta,rbf,lamda )
%
% calculate the gradient of J(w)
%
% Input:
%   x,y: dataset
%   theta: the vector used for logistic regression
%   
% Output:
%   grad_J: gradient 
% 


fx = 1.0./(1+exp(-theta*rbf.*y')); 

grad_J = 1.0/length(y)*sum(repmat((fx-1)'.*y,1,length(rbf)).*rbf')+ 2*lamda*theta;
Jw = -1.0/length(y)* sum(log(fx))+lamda* theta*(theta');
%grad=0;
% for i=1:length(y)
%     grad = grad+fx(i)*y(i)*rbf(:,i)'+2*lamda*theta;
% end
%   grad_J = grad/length(y)+2*lamda*theta;
end

