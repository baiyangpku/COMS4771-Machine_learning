function [ logistic ] = logistic( x )
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here
logistic =  1.0./(1+exp(-x));
 
end

