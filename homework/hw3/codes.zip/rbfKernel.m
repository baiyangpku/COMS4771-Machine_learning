function [ rbf ] = rbfKernel(xtrain,xtest )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
L=length(xtrain);
W=length(xtest);
x=xtrain';
xt=xtest';
rbfKer = zeros(L,L);
for i=1:W
    rbfKer(i,:) = sum((repmat(xt(1:end,i),[1,L])-x).^2);
end

K = sum(sum(rbfKer))/(L^2);
rbf = exp(-rbfKer./K);
rbf=rbf';
end

