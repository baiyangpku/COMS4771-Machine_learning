
clear all 
close all

load('data1.mat');
 
tolerance=0.01;
lamda=0.01;
p=1;
stepsize=0.01;
rbf = rbfKernel(TrainingX,TrainingX);
%tic
[theta, t,Jw, timer]= stochasticGD(rbf, TrainingY,tolerance,stepsize,p,lamda);
%toc
% 
figure 
plot(timer, Jw)

sig = logistic(theta*rbf);
logis=ones(length(sig),1);
logis(find(sig <=0.5))=-1;  
Binary_Error=nnz(TrainingY-logis)

rbf2 = rbfKernel(TrainingX,TestX);
sigT = logistic(theta*rbf2);
logisT=ones(length(TestY),1);
logisT(find(sigT <=0.5))=-1;  
Binary_Error_test=nnz(TestY-logisT)

