clc
clear all
close all

load('data1.mat');
stepsize=0.1;
tolerance=0.01;
lamda=0.01;

theta0 = rand(1,length(TrainingX));
rbf = rbfKernel(TrainingX,TrainingX);
%tic
[theta, t,timer, Jw]= grad_des(theta0, stepsize, tolerance, TrainingY, rbf, lamda);
%toc

figure 
plot(timer(1:550), Jw(1:550))

% sig = logistic(theta*rbf);
% logis=ones(length(sig),1);
% logis(find(sig <=0.5))=-1;  
% Binary_Error=nnz(TrainingY-logis)

rbf2 = rbfKernel(TrainingX,TestX);
sigT = logistic(theta*rbf2);
logisT=ones(length(TestY),1);
logisT(find(sigT <=0.5))=-1;  
Binary_Error_test=nnz(TestY-logisT)
