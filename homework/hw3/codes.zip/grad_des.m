function [ theta, iteration_num,timeT, Jw ] = grad_des(theta0,stepsize,tolerance,y,rbf ,lamda)
% 
%   gradient descend algorithm
%
% Inputs:
%   theta0: initial theta 
%   step: step size
%   tolerance: tolerance
%   x,y: dataset 
%   
% Output:
%   theta: the best model for logistic regression
%   iteration_num: number of iterations
%
%
[gradient, J0]=gradJ_logistic(y,theta0,rbf, lamda);
theta1=theta0-stepsize*gradient;
t=1;
theta_t2=theta1;
timer=[];
Jw=[];
tic
while norm(gradient)>=tolerance
    theta_t1=theta_t2;
    [gradient, Jt]=gradJ_logistic(y,theta_t1,rbf, lamda);
    theta_t2=theta_t1-stepsize* gradient;
    t=t+1;
    %norm(gradient)
    timer=[timer,toc];
    Jw=[Jw,Jt];
end
iteration_num=t
theta=theta_t2;
timeT=timer;




end

