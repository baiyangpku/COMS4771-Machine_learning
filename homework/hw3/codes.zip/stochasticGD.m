function [ theta, itera_t, Jw, timer ] = stochasticGD( rbf, y,tolerance,stepsize,p,lamda )
%UNTITLED10 Summary of this function goes here
%   Detailed explanation goes here
theta0=zeros(1,length(y));
[gradient, J0]=gradJ_logistic(y,theta0,rbf, lamda);
t=0;
timer=[];
Jw=[];
theta_t2=theta0;
timepass=0;
toleranc=0.1;
tic
while norm(gradient)>=toleranc && timepass<15
    n=randi([1,length(y)],1,p);
    for i=1:p
        if(y(n(i))*theta_t2*rbf(:,n(i))<=0) 
             theta_t1=theta_t2;            
             theta_t2=theta_t1+stepsize*y(n(i)).*(rbf(:,n(i))');
             [gradient, Jt]=gradJ_logistic(y,theta_t2,rbf, lamda);
             t=t+1;
             timer=[timer,toc];
             Jw=[Jw,Jt];
        end
        %norm(gradient)
    end
    timepass=toc;
end
itera_t=t
theta=theta_t2;







end

